import socket
import sys




class Client():

    def __init__(self,addr, port, sock=False):

        self.addr = addr
        self.port = port
        if sock is False:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def get_server(self):

        try:
            host = self.sock.connect((self.addr, self.port))
        except:
            print("ERROR")
        return host

    def send_mssg(self, msg):
        
        self.get_server()
        self.sock.send( msg.encode() ) 
        try:
            print(self.return_msg() )
        except:
            print("No answer")

    def return_msg(self):
        return self.sock.recv(1024)

client = Client("127.0.0.1", 5000)
client.send_mssg(sys.argv[1])
