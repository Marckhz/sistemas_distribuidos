import socket


class Server():
    
    def __init__(self,addr, port, sock=False):
        

        self.addr = addr
        self.port = port

        if sock is False:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def create_connection(self):
    
        self.sock.bind((self.addr, self.port))
        self.sock.listen(1)
        
        conn, address = self.sock.accept()
        return conn, address
    
    def start_connection(self):
        print("listening from", self.addr)
        host = self.create_connection()
        if host[0]:
            try:
                while True:
                    data = host[0].recv(1024)
                    if data:
                        print("got ", str(data), "from", host[1] )
                        break
            except:
                print("Error")
            finally:
                if data:
                    host[0].send(b"got the message")
                    host[0].close()


my_server = Server('127.0.0.1', 5000)
my_server.start_connection()




